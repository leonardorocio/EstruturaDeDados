
typedef struct no{
	void *info;
	int fb;
	struct no *esq, *dir, *pai;
}NoAVL;

typedef struct{
	int tamanhoInfo;
	NoAVL *raiz;
}ArvoreAVL;

void inicializa_AVL( ArvoreAVL *a, int t );
void insere_AVL( ArvoreAVL *a, void *info, int (*compara_info)(void *, void *) );
void remove_AVL( ArvoreAVL *a, void *info, int (*compara_info)(void *, void *) );
void limpa_AVL( ArvoreAVL *a );
int busca_AVL( ArvoreAVL a, void *chave, int (*compara_info)(void *, void *) );
void percurso_pre_ordem( ArvoreAVL a, void (*mostra_info)(void *) );
void percurso_em_ordem( ArvoreAVL a, void (*mostra_info)(void *) );
void percurso_pos_ordem( ArvoreAVL a, void (*mostra_info)(void *) );
void mostra_estrutura( ArvoreAVL a, void (*mostra_info)(void *) );

int altura( NoAVL *n );

