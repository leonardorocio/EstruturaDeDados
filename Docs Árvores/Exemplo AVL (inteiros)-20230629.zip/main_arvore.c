#include <stdio.h>
#include <stdlib.h>
#include "ArvoreAVL.h"
#include "FilaEncadeada.h"

void mostra_int( void *info );
int compara_int( void *a, void *b );

int main(int argc, char *argv[])
{
	ArvoreAVL arvore;
   
	inicializa_AVL( &arvore, sizeof(int) );
	percurso_em_ordem( arvore, mostra_int );
	system("PAUSE");
	system("CLS");

	int x;

	printf("Digite um valor (0 para parar a insercao): ");
	scanf("%d", &x );
	while( x != 0 ){
		printf("%Inserindo %d...\n\n", x);
		insere_AVL( &arvore, &x, compara_int );
		mostra_estrutura( arvore, mostra_int );
   		system("PAUSE");
   		system("CLS");
		printf("Digite um valor (0 para parar a insercao): ");
		scanf("%d", &x );
	}
   
   percurso_em_ordem( arvore, mostra_int );
   system("PAUSE");
   system("CLS");
   
   percurso_pre_ordem( arvore, mostra_int );
   system("PAUSE");
   system("CLS");
   
   percurso_pos_ordem( arvore, mostra_int );
   system("PAUSE");
   system("CLS");

   percurso_em_largura( arvore, mostra_int );
   system("PAUSE");
   system("CLS");

   int y;
   printf("Digite um valor:\n");
   scanf("%d", &y);
   printf("%Buscando %d...\n\n", y);
   if( busca_AVL(arvore, &y, compara_int) )
      printf("%d encontrado!!\n\n", y);
   else
      printf("%d nao encontrado!!\n\n", y);
   system("PAUSE");
   system("CLS");

   printf("Limpando arvore...\n\n");
   limpa_AVL( &arvore );
   percurso_em_ordem( arvore, mostra_int );
   mostra_estrutura( arvore, mostra_int );

   printf("Fim da demosntracao.\n\n");
   system("PAUSE");
   return 0;
}

void mostra_int( void *info ){
   int *p = (int *) info;
   printf("%i\n", *p);
}

int compara_int( void *a, void *b ){
    int *pa = a, *pb = b;
    
    return *pa - *pb;
}

