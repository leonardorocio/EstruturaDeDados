#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArvoreAVL.h"
#include "FilaEncadeada.h"

// ---------- private -----------

NoAVL *inicializa_no_AVL( void *info, int t ){
	NoAVL *p = malloc( sizeof(NoAVL) );
	if( p == NULL )
		return NULL;
	p->info = malloc( t );
	if( p->info == NULL ){
		free( p );
		return NULL;
	}
	memcpy( p->info, info, t );
	p->esq = NULL;
	p->dir = NULL;
	p->pai = NULL;
	p->fb = 0;
	return p;
}

int insere_no_AVL( NoAVL *n, void *info, int t, int (*compara_info)(void *, void *) ){
	if ( n == NULL )
		return 0; // n�o achou.

	if ( compara_info( info, n->info ) < 0 ){
		int achou = insere_no_AVL( n->esq, info, t, compara_info );
		if( !achou ){
			n->esq = inicializa_no_AVL(info, t);
			n->esq->pai = n;
		}
	return 1; // propaga que foi inserido.
	}

	if ( compara_info( info, n->info ) > 0 ){
		int achou = insere_no_AVL( n->dir, info, t, compara_info );
		if( !achou ){
			n->dir = inicializa_no_AVL( info, t );
			n->dir->pai = n;
		}
		return 1; // propaga que foi inserido.
	}
  
	return 1; // achou
}

NoAVL *procura_menor_a_direita( NoAVL *n ){
	while( n->esq != NULL )
		n = n->esq;
	return n;
}

void troca_info( NoAVL *a, NoAVL *b ){
	void *temp = a->info;
	a->info = b->info;
	b->info = temp;
}

void arruma_ponteiros_pai( NoAVL *n, NoAVL *filho ){
	NoAVL *pai = n->pai;

	if( pai != NULL ){
		if( pai->esq == n )
			pai->esq = filho;
		else
			pai->dir = filho;
	}

	if( filho != NULL )
		filho->pai = pai;
}

void remove_no_simples(NoAVL *n){
	if( n->esq == NULL && n->dir == NULL ) // n� folha
		arruma_ponteiros_pai( n, NULL );
	else 
		if( n->esq != NULL ) // n� com um filho � esquerda
			arruma_ponteiros_pai( n, n->esq );
		else // n� com um filho � direita
			arruma_ponteiros_pai( n, n->dir );

	free(n->info);
	free(n);
}


NoAVL *busca_AVL_rec( NoAVL *n, void *chave, int (*compara_info)(void *, void *) ){
	if ( n == NULL )
		return NULL;

	if ( compara_info ( chave, n->info ) < 0 )
		return busca_AVL_rec( n->esq, chave, compara_info );

	if ( compara_info( chave, n->info ) > 0)
		return busca_AVL_rec( n->dir, chave, compara_info );

	return n;
}

void limpa_pos_ordem( NoAVL *n ){
	if( n != NULL ){
		limpa_pos_ordem( n->esq );
		limpa_pos_ordem( n->dir );
		free( n->info );
		free( n );
	}
}

void pre_ordem( NoAVL *n, void (*mostra_info)(void *) ){
	if( n != NULL ){
		mostra_info( n->info );
		pre_ordem( n->esq, mostra_info );
		pre_ordem( n->dir, mostra_info );
	}
}

void em_ordem( NoAVL *n, void (*mostra_info)(void *) ){
	if( n != NULL ){
		em_ordem(n->esq, mostra_info );
		mostra_info( n->info) ;
		em_ordem( n->dir, mostra_info );
	}
}

void pos_ordem( NoAVL *n, void (*mostra_info)(void *) ){
	if( n != NULL ){
		pos_ordem( n->esq, mostra_info );
		pos_ordem( n->dir, mostra_info );
		mostra_info( n->info );
	}
}

void pre_ordem_modificado(NoAVL *n, int nivel, void (*mostra_info)(void *) ){
	int i;
	for( i=0; i<nivel-1 ; i++ )
		printf("    ");
	printf("+---");

	if( n != NULL ){
		mostra_info( n->info );
		pre_ordem_modificado( n->esq, nivel+1, mostra_info );
		pre_ordem_modificado( n->dir, nivel+1, mostra_info );
	}
	else
		printf("(null)\n");
}

int altura( NoAVL *n ){
	if( n == NULL )
		return 0;
	else{
		if( n->esq == NULL && n->dir == NULL )
			return 1;
		else{
			int esq = altura( n->esq );
			int dir = altura( n->dir );
			if( esq > dir )
				return 1 + esq;
			else
				return 1 + dir;
		}
	}
}

NoAVL *verifica_balanceamento( NoAVL *n ){
	if( n != NULL ){
  
		NoAVL *p = verifica_balanceamento( n->esq );
		if( p != NULL )
			return p;
      
		p = verifica_balanceamento( n->dir );
		if( p != NULL )
			return p;
      
		n->fb = altura( n->esq ) - altura( n->dir );
		if( n->fb == 2 || n->fb == -2 )
			return n;
	}
	return NULL;
}

void rotacao_a_direita( NoAVL *pai, NoAVL *filho, ArvoreAVL *a ){

	pai->esq = filho->dir; // pai desce e 'adota' filho do filho
	if( pai->esq != NULL )
		pai->esq->pai = pai;
   
	filho->dir = pai;      // filho sobe e se torna o pai
	filho->pai = pai->pai;
	pai->pai = filho;
   
	NoAVL *avo = filho->pai;  // caso exista um 'avo', arrumar os ponteiros
	if( avo != NULL ){
		if( avo->esq == pai )
			avo->esq = filho;
		else
		avo->dir = filho;
	}
	else                    // caso contrario, o filho (que subiu), se torna o raiz
		a->raiz = filho;
}

void rotacao_a_esquerda( NoAVL *pai, NoAVL *filho, ArvoreAVL *a ){
	pai->dir = filho->esq;
	if( pai->dir != NULL )
		pai->dir->pai = pai;

	filho->esq = pai;
	filho->pai = pai->pai;
	pai->pai = filho;

	NoAVL *avo = filho->pai;
	if( avo != NULL ){
		if( avo->esq == pai )
			avo->esq = filho;
		else
			avo->dir = filho;
	}
	else
		a->raiz = filho;
}

void executa_balancemanto( NoAVL *n, ArvoreAVL *a ){
	if( n->fb > 0 ){ // rota��o � direita
		if( n->esq->fb < 0 ){ // dupla
			printf("Rotacao dupla a direita...\n");
			rotacao_a_esquerda( n->esq, n->esq->dir, a );
			rotacao_a_direita( n, n->esq, a );
		}
		else{ // simples
			printf("Rotacao simples a direita...\n");
			rotacao_a_direita( n, n->esq, a );
		}
	}
	else{ // rota��o � esquerda
		if( n->dir->fb > 0 ){ // dupla
			printf("Rotacao dupla a esquerda...\n");
			rotacao_a_direita( n->dir, n->dir->esq, a );
			rotacao_a_esquerda( n, n->dir, a );
		}
		else{ // simples
			printf("Rotacao simples a esquerda...\n");
			rotacao_a_esquerda( n, n->dir, a );
		}
	}
}


// ---------- public -----------

void inicializa_AVL( ArvoreAVL *a, int t ){
	a->tamanhoInfo = t;
	a->raiz = NULL;
}

void insere_AVL( ArvoreAVL *a, void *info, int (*compara_info)(void *, void *) ){
	if( a->raiz == NULL )
		a->raiz = inicializa_no_AVL( info, a->tamanhoInfo );
	else{
		insere_no_AVL( a->raiz, info, a->tamanhoInfo, compara_info );

		// ******** Verifica balanceamento ********
		NoAVL *p = verifica_balanceamento( a->raiz );
		if( p != NULL ){
			executa_balancemanto( p, a );
		}
		// ****************************************
	}
}

void remove_AVL( ArvoreAVL *a, void *info, int (*compara_info)(void *, void *) ){
	NoAVL *n = busca_AVL_rec( a->raiz, info, compara_info );

	if( n->esq != NULL && n->dir != NULL ){ // n� com 2 filhos
		NoAVL *menor = procura_menor_a_direita( n->dir );
		troca_info( n, menor );
		n = menor; // a aponta para o menor, que ser� removido a seguir.
	}
 
	remove_no_simples( n );
	
	// ******** Verifica balanceamento ********
	NoAVL *p = verifica_balanceamento( a->raiz );
	while(p != NULL ){
		executa_balancemanto( p, a );
		p = verifica_balanceamento( a->raiz );
	}
	// ****************************************
}

/*
Funcao booleana, mas tambem atualiza a variavel apontada por 'chave'
com a informacao retornada na busca, caso encontrada. Isso ocorre, pois
a busca pode ser feita com base em somente um dos campos de uma struct,
tal como o codigo de um produto. A busca vai entao retornar a estrutura
completa, cujo conteudo eh atualizado na 'chave'. Assim, quem faz a chamada
da busca pode obter um registro completo com base em somente um ou mais campos.
*/
int busca_AVL( ArvoreAVL a, void *chave, int (*compara_info)(void *, void *) ){
	NoAVL *n = busca_AVL_rec( a.raiz, chave, compara_info );
	if( n == NULL )
		return 0; // Nao encontrou!

	memcpy( chave, n->info, a.tamanhoInfo );
	return 1; // Encontrou!
}

void limpa_AVL( ArvoreAVL *a ){
	if( a->raiz != NULL ){
		limpa_pos_ordem( a->raiz );
		a->raiz = NULL;
	}
}

void percurso_pre_ordem( ArvoreAVL a, void (*mostra_info)(void *) ){
	if( a.raiz == NULL )
		printf("Arvore vazia!\n");
	else{
		printf("Percurso em Pre-Ordem:\n\n");
		pre_ordem( a.raiz, mostra_info );
	}
	printf("----------------------\n\n");
}

void percurso_em_ordem( ArvoreAVL a, void (*mostra_info)(void *) ){
	if( a.raiz == NULL )
		printf("Arvore vazia!\n");
	else{
		printf("Percurso Em-Ordem:\n\n");
		em_ordem( a.raiz, mostra_info );
	}
	printf("----------------------\n\n");
}

void percurso_pos_ordem( ArvoreAVL a, void (*mostra_info)(void *) ){
	if( a.raiz == NULL )
		printf("Arvore vazia!\n");
	else{
		printf("Percurso em Pos-Ordem:\n\n");
		pos_ordem( a.raiz, mostra_info );
	}
	printf("\n----------------------\n\n");
}

void percurso_em_largura( ArvoreAVL a, void (*mostra_info)(void *) ){
	if( a.raiz == NULL )
		printf("Arvore vazia!\n");
	else{
		printf("Percurso em largura:\n\n");
		FilaEncadeada f;
		inicializaFila (&f, sizeof( NoAVL ) ); // Fila de n�s da �rvore
		inserir( &f, a.raiz ); // O campo "raiz" � um ponteiro, portanto, n�o precisa do "&"...
		while( !filaVazia( f ) ){
			NoAVL n;
			remover( &f, &n );
			mostra_info( n.info );	// Mostra n� (1o. da fila)
			if( n.esq != NULL )		// Insere filhos na fila
				inserir( &f, n.esq );
			if( n.dir != NULL )
				inserir( &f, n.dir );
		}
		limpaFila( &f );
	}
	printf("----------------------\n\n");
}

void mostra_estrutura( ArvoreAVL a, void (*mostra_info)(void *) ){
	printf("Estrutura da Arvore:\n\n");
	if( a.raiz == NULL )
		printf("(null)\n");
	else{
		mostra_info( a.raiz->info );
		pre_ordem_modificado( a.raiz->esq, 1, mostra_info );
		pre_ordem_modificado( a.raiz->dir, 1, mostra_info );
	}
	printf("----------------------\n\n");
}

