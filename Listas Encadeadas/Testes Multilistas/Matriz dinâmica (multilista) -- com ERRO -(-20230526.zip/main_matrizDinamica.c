#include <stdio.h>
#include <stdlib.h>
#include "MatrizDinamica.h"

int main(int argc, char *argv[]) {
	MatrizDinamica m;
	
	inicializa_matriz( &m, 3, 4);
	mostra_matriz( m );
	modifica( m, 0, 0, 100 );
	mostra_matriz( m );
	
	return 0;
}
